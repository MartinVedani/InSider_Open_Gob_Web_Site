var members = data.results[0].members;

// Big Data Tables

if (document.getElementById("table-data-body")) {
    var table = document.getElementById("table-data-body");
    for (var i = 0; i < members.length; i++) {
        row = table.insertRow(i);
        cell1 = row.insertCell(0);
        cell2 = row.insertCell(1);
        cell3 = row.insertCell(2);
        cell4 = row.insertCell(3);
        cell5 = row.insertCell(4);

        cell1.innerHTML = (members[i].first_name.concat(" ", members[i].middle_name || "", " ", members[i].last_name)).link(members[i].url);
        cell2.innerHTML = members[i].party;
        cell3.innerHTML = members[i].state;
        cell4.innerHTML = members[i].seniority;
        cell5.innerHTML = (members[i].votes_with_party_pct).toFixed(2);
    };
};

// Checkboxes and Selector Menu filters for big data tables
function filterDataTable() {
    var rows = document.getElementById("congressDataTable").rows;
    var tdParty;
    var tdState;
    selectedState = document.getElementById("selectState").value;
    checkedR = document.getElementById("checkR").checked;
    checkedD = document.getElementById("checkD").checked;
    checkedI = document.getElementById("checkI").checked;
    for (var i = 1; i < rows.length; i++) {
        rows[i].classList.add("d-none"); //esconder todas las filas agregando "d-none"
        tdParty = rows[i].cells[1].textContent;
        tdState = rows[i].cells[2].textContent;
        if (
            (selectedState == tdState || selectedState == "") &&
            (
                checkedR && tdParty.includes("R") ||
                checkedD && tdParty.includes("D") ||
                checkedI && tdParty.includes("I"))
        ) {
            rows[i].classList.remove("d-none"); //mostrar las filas q cumplen "if" removiendo "d-none"
        }
    }
};