var members = data.results[0].members;

var stats = {
    "showTablePercent": 0.1,
    "republicans": [],
    "democrats": [],
    "independents": [],
    "countR": 0,
    "countD": 0,
    "countI": 0,
    "countTotal": members.length,
    "sumR": 0,
    "sumD": 0,
    "sumI": 0,
    "sumTotal": 0,
    "avgR": 0,
    "avgD": 0,
    "avgI": 0,
    "avgTotal": 0,
    "leastEngaged": [],
    "mostEngaged ": [],
    "leastLoyal": [],
    "mostLoyal": [],
}

function glanceTable() {
    for (var i = 0; i < members.length; i++) {

        stats.sumTotal = stats.sumTotal + members[i].votes_with_party_pct;

        if (members[i].party.includes("R")) {
            stats.republicans.push(members[i]);
            stats.sumR = stats.sumR + members[i].votes_with_party_pct;
        };

        if (members[i].party.includes("D")) {
            stats.democrats.push(members[i]);
            stats.sumD = stats.sumD + members[i].votes_with_party_pct;
        };

        if (members[i].party.includes("I")) {
            stats.independents.push(members[i]);
            stats.sumI = stats.sumI + members[i].votes_with_party_pct;
        };
    };

    stats.countR = stats.republicans.length;
    stats.countD = stats.democrats.length;
    stats.countI = stats.independents.length;

    stats.sumR = (stats.sumR).toFixed(2);
    stats.sumD = (stats.sumD).toFixed(2);
    stats.sumI = (stats.sumI).toFixed(2);

    stats.avgR = (stats.sumR / stats.countR).toFixed(2);
    stats.avgD = (stats.sumD / stats.countD).toFixed(2);
    stats.avgI = (stats.sumI / stats.countI).toFixed(2);

    if (isNaN(stats.avgI)) {
        stats.avgI = 0;
        stats.avgI = stats.avgI.toFixed(2);
    };

    stats.avgTotal = (stats.sumTotal / stats.countTotal).toFixed(2);

    // At a glance tables, tbody id="glanceTable-body"

    var table = document.getElementById("glanceTable-body");

    for (var i = 0; i < 4; i++) {
        if (i == 0) {
            row = table.insertRow(i);
            cell1 = row.insertCell(0);
            cell2 = row.insertCell(1);
            cell3 = row.insertCell(2);

            cell1.innerHTML = "Republicans";
            cell2.innerHTML = stats.countR;
            cell3.innerHTML = stats.avgR;

        } else if (i == 1) {
            row = table.insertRow(i);
            cell1 = row.insertCell(0);
            cell2 = row.insertCell(1);
            cell3 = row.insertCell(2);

            cell1.innerHTML = "Democrats";
            cell2.innerHTML = stats.countD;
            cell3.innerHTML = stats.avgD;

        } else if (i == 2) {
            row = table.insertRow(i);
            cell1 = row.insertCell(0);
            cell2 = row.insertCell(1);
            cell3 = row.insertCell(2);

            cell1.innerHTML = "Independents";
            cell2.innerHTML = stats.countI;
            cell3.innerHTML = stats.avgI;

        } else {
            row = table.insertRow(i);
            cell1 = row.insertCell(0);
            cell2 = row.insertCell(1);
            cell3 = row.insertCell(2);

            cell1.innerHTML = "Total";
            cell2.innerHTML = stats.countTotal;
            cell3.innerHTML = stats.avgTotal;
        };

    };
};

if (document.getElementById("glanceTable-body")) {
    glanceTable();
};

// SORT TABLE variable

function compareMissed(a, b) {
    if (a.missed_votes_pct > b.missed_votes_pct) {
        return 1;
    } else if (a.missed_votes_pct < b.missed_votes_pct) {
        return -1;
    } else {
        return 0;
    };
};

// ENGAGED tables, tbody id least and most

function mostEngagedTable() {
    stats.mostEngaged = members.sort(compareMissed);
    var table = document.getElementById("mostEngagedTable-body");
    for (var i = 0; i < members.length * stats.showTablePercent; i++) {
        row = table.insertRow(i);
        cell1 = row.insertCell(0);
        cell2 = row.insertCell(1);
        cell3 = row.insertCell(2);

        cell1.innerHTML = (stats.mostEngaged[i].first_name.concat(" ", stats.mostEngaged[i].middle_name || "", " ", stats.mostEngaged[i].last_name)).link(stats.mostEngaged[i].url);
        cell2.innerHTML = stats.mostEngaged[i].missed_votes;
        cell3.innerHTML = (stats.mostEngaged[i].missed_votes_pct).toFixed(2);
    };
};

if (document.getElementById("mostEngagedTable-body")) {
    mostEngagedTable();
};

function leastEngagedTable() {
    stats.mostEngaged = members.sort(compareMissed);
    stats.leastEngaged = stats.mostEngaged.reverse();
    var table = document.getElementById("leastEngagedTable-body");
    for (var i = 0; i < members.length * stats.showTablePercent; i++) {
        row = table.insertRow(i);
        cell1 = row.insertCell(0);
        cell2 = row.insertCell(1);
        cell3 = row.insertCell(2);

        cell1.innerHTML = (stats.leastEngaged[i].first_name.concat(" ", stats.leastEngaged[i].middle_name || "", " ", stats.leastEngaged[i].last_name)).link(stats.leastEngaged[i].url);
        cell2.innerHTML = stats.leastEngaged[i].missed_votes;
        cell3.innerHTML = (stats.leastEngaged[i].missed_votes_pct).toFixed(2);
    };
};

if (document.getElementById("leastEngagedTable-body")) {
    leastEngagedTable();
};

// LOYALTY tables

function compareLoyalty(a, b) {
    if (a.votes_with_party_pct > b.votes_with_party_pct) {
        return 1;
    } else if (a.votes_with_party_pct < b.votes_with_party_pct) {
        return -1;
    } else {
        return 0;
    };
};

function leastLoyaltyTable() {
    stats.leastLoyal = members.sort(compareLoyalty);
    var table = document.getElementById("leastLoyaltyTable-body");
    for (var i = 0; i < members.length * stats.showTablePercent; i++) {
        row = table.insertRow(i);
        cell1 = row.insertCell(0);
        cell2 = row.insertCell(1);
        cell3 = row.insertCell(2);

        cell1.innerHTML = (stats.leastLoyal[i].first_name.concat(" ", stats.leastLoyal[i].middle_name || "", " ", stats.leastLoyal[i].last_name)).link(stats.leastLoyal[i].url);
        cell2.innerHTML = (stats.leastLoyal[i].total_votes * (stats.leastLoyal[i].votes_with_party_pct / 100)).toFixed(0);
        cell3.innerHTML = (stats.leastLoyal[i].votes_with_party_pct).toFixed(2);
    };
};

if (document.getElementById("leastLoyaltyTable-body")) {
    leastLoyaltyTable();
};

function mostLoyaltyTable() {
    stats.leastLoyal = members.sort(compareLoyalty);
    stats.mostLoyal = stats.leastLoyal.reverse();
    var table = document.getElementById("mostLoyaltyTable-body");
    for (var i = 0; i < members.length * stats.showTablePercent; i++) {
        row = table.insertRow(i);
        cell1 = row.insertCell(0);
        cell2 = row.insertCell(1);
        cell3 = row.insertCell(2);

        cell1.innerHTML = (stats.mostLoyal[i].first_name.concat(" ", stats.mostLoyal[i].middle_name || "", " ", stats.mostLoyal[i].last_name)).link(stats.mostLoyal[i].url);
        cell2.innerHTML = (stats.mostLoyal[i].total_votes * (stats.mostLoyal[i].votes_with_party_pct / 100)).toFixed(0);
        cell3.innerHTML = (stats.mostLoyal[i].votes_with_party_pct).toFixed(2);
    };
};

if (document.getElementById("mostLoyaltyTable-body")) {
    mostLoyaltyTable();
};