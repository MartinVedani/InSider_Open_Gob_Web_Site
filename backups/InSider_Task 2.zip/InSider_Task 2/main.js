var members = data.results[0].members;

// Create table with public data
var table = document.getElementById("table-head");
var row = table.insertRow(0);
var cell1 = document.createElement("th"); //row.insertCell(0);
var cell2 = document.createElement("th"); //row.insertCell(1);
var cell3 = document.createElement("th"); //row.insertCell(2);
var cell4 = document.createElement("th"); //row.insertCell(3);
var cell5 = document.createElement("th"); //row.insertCell(4);
cell1.innerHTML = "FULL NAME";
cell2.innerHTML = "PARTY";
cell3.innerHTML = "STATE";
cell4.innerHTML = "SENIORITY";
cell5.innerHTML = "% VOTES W/ PARTY";
row.appendChild(cell1);
row.appendChild(cell2);
row.appendChild(cell3);
row.appendChild(cell4);
row.appendChild(cell5);

for (var i = 0; i < members.length; i++) {
    table = document.getElementById("table-body");
    row = table.insertRow(i);
    cell1 = row.insertCell(0);
    cell2 = row.insertCell(1);
    cell3 = row.insertCell(2);
    cell4 = row.insertCell(3);
    cell5 = row.insertCell(4);

    var full_name = members[i].first_name.concat(" ", members[i].middle_name || "", " ", members[i].last_name);

    cell1.innerHTML = full_name.link(members[i].url)
    cell2.innerHTML = members[i].party;
    cell3.innerHTML = members[i].state;
    cell4.innerHTML = members[i].seniority;
    cell5.innerHTML = members[i].votes_with_party_pct;
}

// Checkboxes and Selector Menu filters
function filterTable() {
    var rows = document.getElementById("congressTable").rows;
    var tdParty;
    var tdState;
    for (var i = 1; i < rows.length; i++) {
        rows[i].classList.add("d-none");
        tdParty = rows[i].cells[1].textContent;
        tdState = rows[i].cells[2].textContent;
        if (
            (document.getElementById("selectState").value == tdState || document.getElementById("selectState").value == "") &&
            (
                document.getElementById("checkR").checked && tdParty.includes("R") ||
                document.getElementById("checkI").checked && tdParty.includes("I") ||
                document.getElementById("checkD").checked && tdParty.includes("D"))
        ) {
            rows[i].classList.remove("d-none");
        }
    }
};